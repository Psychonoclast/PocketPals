using System;
using XRL;
using XRL.World;
using XRL.World.Effects;

namespace XRL.World.Parts
{
[Serializable]
public class AzPx_LifeDrainOnHit : IPart
{
	public int Chance = 100;

	public string Duration = "2";

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "WeaponHit");
		Object.RegisterPartEvent(this, "ProjectileHit");
		Object.RegisterPartEvent(this, "WeaponThrowHit");
		base.Register(Object);
	}

	public override bool FireEvent(Event E)
	{
		if (E.ID == "WeaponHit" || E.ID == "WeaponThrowHit" || E.ID == "ProjectileHit")
		{
			GameObject defender = E.GetGameObjectParameter("Defender");
			GameObject attacker = E.GetGameObjectParameter("Attacker");
			if (defender != null && Chance.in100())
			{
					defender.ApplyEffect(new XRL.World.Effects.LifeDrain(10, 12, "1-4", attacker, false));
			}
		}
		return base.FireEvent(E);
	}
}
}