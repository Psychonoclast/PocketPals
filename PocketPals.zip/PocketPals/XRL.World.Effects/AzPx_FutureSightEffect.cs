using System;
using XRL;
using XRL.Core;
using XRL.Rules;
using XRL.World;
using XRL.World.Capabilities;
using XRL.World.Effects;
using XRL.World.Parts;

namespace XRL.World.Effects
{
[Serializable]
public class AzPx_FutureSightEffect : Effect
{
	public GameObject Owner;
	
	public int duration = 2;
	
	public int remove = 0;

	public AzPx_FutureSightEffect()
	{
		base.DisplayName = "{{M|targeted}}";
	}

	public AzPx_FutureSightEffect(int Duration, GameObject Owner = null)
		: this()
	{
		base.Duration = Duration;
		this.Owner = Owner;
	}

	public override bool SameAs(Effect e)
	{
		return false;
	}

	public override string GetDetails()
	{
		return "After two turns, a powerful psychic blast strikes this target.";
	}

	public override bool Apply(GameObject Object)
	{
		AzPx_FutureSightEffect sighted = Object.GetEffect("AzPx_FutureSightEffect") as AzPx_FutureSightEffect;
		if (sighted != null)
		{
			if (Duration > sighted.Duration)
			{
				sighted.duration = duration;
			}
		}
		/* {
			DidX("have", "been targeted by future sight", "!", null, null, Object);
			return true;
		} */
		return false;
	}

	public override void Remove(GameObject Object)
	{
	}

	public override bool WantEvent(int ID, int cascade)
	{
		if (!base.WantEvent(ID, cascade))
		{
			return ID == GeneralAmnestyEvent.ID;
		}
		return true;
	}

	public override bool HandleEvent(GeneralAmnestyEvent E)
	{
		Owner = null;
		return true;
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterEffectEvent(this, "EndTurn");
		base.Register(Object);
	}

	public override void Unregister(GameObject Object)
	{
		Object.UnregisterEffectEvent(this, "EndTurn");
		base.Unregister(Object);
	}

	public override bool Render(RenderEvent E)
	{
		int num = XRLCore.CurrentFrame % 60;
		if (num > 35 && num < 45)
		{
			E.Tile = null;
			E.RenderString = "\u0030";
			E.ColorString = "&W^M";
		}
		return true;
	}

	public override bool FireEvent(Event E)
	{
		if (E.ID == "EndTurn")
			{
				GameObject.validate(ref Owner);
				if (Duration == 0 && remove != 1)
				{
					int damageroll = (int)(Stat.Roll("2d20"));
					Damage damage = new Damage(damageroll);
					damage.AddAttribute("Mental");
					Event @event = Event.New("TakeDamage");
					@event.SetParameter("Damage", damage);
					@event.SetParameter("Owner", Owner);
					@event.SetParameter("Attacker", Owner);
					@event.SetParameter("Message", "from %t {{M|future sight}}!");
					base.Object.FireEvent(@event);
					Object?.CurrentCell?.PsychicPulse();
					remove = 1;
				}
				if (Duration > 0)
				{
					Duration--;
				}
			}
		return base.FireEvent(E);
	}
}
}