using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleLib.Console;
using Qud.API;
using XRL;
using XRL.Core;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Capabilities;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;
using XRL.World.Parts.Skill;

namespace XRL.World.Parts
{
[Serializable]
public class AzPx_EvolutionOshawott : IPart
{
	
	public int evostage = 0;
	
	public int evocheck = 0;
	
	public int levelcheck = 0;
	
	public override bool WantEvent(int ID, int cascade)
	{
	if(ID == AwardXPEvent.ID)
		return true;

	return base.WantEvent(ID, cascade);
	}


	public bool HandleEvolution()
	{
		if (evostage == 1 && evocheck <= 0)
		{
			GameObject parent = ParentObject;
					Render render = ParentObject.pRender;
					if (parent.IsPlayer())
					{
						render.Tile="Player/AzPx_DewottTile";
					}
					else
					{
					render.Tile="Creatures/AzPx_DewottTile.bmp";
					}
					if (render.DisplayName == "Oshawott")
					{
					render.DisplayName="Dewott";
					}
					render.ColorString="C";
					render.DetailColor="B";
					parent.GetStat("Strength").BaseValue += 4;
					parent.GetStat("Agility").BaseValue += 3;
					parent.GetStat("Toughness").BaseValue += 4;
					parent.GetStat("Intelligence").BaseValue += 2;
					parent.GetStat("Willpower").BaseValue += 3;
					parent.GetStat("Ego").BaseValue += 5;
					parent.GetStat("AV").BaseValue += 1;
					parent.Inventory.AddObject("AzPx_Scallchop", bSilent: true);
					evocheck = 1;
					
		}
		if (evostage == 2 && evocheck <= 1)
		{
					GameObject parent = ParentObject;
					Render render = ParentObject.pRender;
					if (parent.IsPlayer())
					{
						render.Tile="Player/AzPx_SamurottTile";
					}
					else
					{
					render.Tile="Creatures/AzPx_SamurottTile.bmp";
					}
					if (render.DisplayName == "Dewott")
					{
					render.DisplayName="Samurott";
					}
					render.ColorString="y";
					render.DetailColor="b";
					parent.GetStat("Strength").BaseValue += 5;
					parent.GetStat("Agility").BaseValue += 2;
					parent.GetStat("Toughness").BaseValue += 4;
					parent.GetStat("Intelligence").BaseValue += 2;
					parent.GetStat("Willpower").BaseValue += 2;
					parent.GetStat("Ego").BaseValue += 5;
					parent.GetStat("AV").BaseValue += 3;
					parent.Inventory.AddObject("AzPx_Seamitar", bSilent: true);
					parent.Inventory.AddObject("AzPx_Seamitar", bSilent: true);
					parent.GetPart<Mutations>()?.AddMutation(new AzPx_PkRazorShellHead(), 1);
					evocheck = 2;
		}
		return true;
	}

	public override bool HandleEvent(AwardXPEvent E)
	{
		if (ParentObject.Stat("Level") >= 12 && evostage == 0 && ParentObject.Stat("Level") > levelcheck)
		{
			if (ParentObject.IsPlayer())
			{
				if (Popup.ShowYesNo("You swell with energy. You are ready to evolve. Will you?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 1;		
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else if (ParentObject.IsPlayerLed())
			{
				if (Popup.ShowYesNo("Your " + ParentObject.DisplayName + " swells with energy. They are ready to evolve. Will you allow them?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 1;
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else
			{
				AddPlayerMessage("Evolution commencing.");
					evostage = 1;
			}
			
		}
		if ( evostage == 1 && evocheck == 0)
		{
			HandleEvolution();
		}
		if (ParentObject.Stat("Level") >= 24 && evostage == 1 && evocheck == 1 && ParentObject.Stat("Level") > levelcheck)
		{
			if (ParentObject.IsPlayer())
			{
				if (Popup.ShowYesNo("You swell with energy. You are ready to evolve. Will you?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 2;
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}	
			}
			else if (ParentObject.IsPlayerLed())
			{
				if (Popup.ShowYesNo("Your " + ParentObject.DisplayName + " swells with energy. They are ready to evolve. Will you allow them?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 2;

				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else
			{
				AddPlayerMessage("Evolution commencing.");
					evostage = 2;

			}
		}
		if ( evostage == 2 & evocheck <= 1)
		{
			HandleEvolution();
		}
		return true;
	}

}
}