using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qud.API;
using XRL.Core;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Capabilities;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;
using XRL.World.Parts.Skill;

namespace XRL.World.Parts
{
[Serializable]
public class AzPx_EvolutionDeerlingSp : IPart
{
	
	public int evostage = 0;
	
	public int levelcheck = 0;
	
	public override bool WantEvent(int ID, int cascade)
	{
	if(ID == AwardXPEvent.ID)
		return true;

	return base.WantEvent(ID, cascade);
	}

	public override bool HandleEvent(AwardXPEvent E)
	{
		if (ParentObject.Stat("Level") >= 16 && evostage == 0 && ParentObject.Stat("Level") > levelcheck)
		{
			if (ParentObject.IsPlayer())
			{
				if (Popup.ShowYesNo("You swell with energy. You are ready to evolve. Will you?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 1;
					GameObject parent = ParentObject;
					Render render = ParentObject.pRender;
					render.Tile="Player/AzPx_SawsbuckSpTile.bmp";
					render.ColorString="w";
					render.DetailColor="M";
					parent.GetStat("Strength").BaseValue += 8;
					parent.GetStat("Agility").BaseValue += 4;
					parent.GetStat("Toughness").BaseValue += 4;
					parent.GetStat("Intelligence").BaseValue += 2;
					parent.GetStat("Willpower").BaseValue += 4;
					parent.GetStat("Ego").BaseValue += 4;
					parent.GetStat("AV").BaseValue += 4;
					BodyPart head = parent.GetFirstBodyPart("Head");
					head.ForceUnequip(false);
					parent.GetPart<Mutations>()?.AddMutation(new AzPx_PkHornLeech(), 1);
					
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else if (ParentObject.IsPlayerLed())
			{
				if (Popup.ShowYesNo("Your " + ParentObject.DisplayName + " swells with energy. They are ready to evolve. Will you allow them?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
				evostage = 1;
				GameObject parent = ParentObject;
				Render render = ParentObject.pRender;
				if (render.DisplayName == "Deerling")
					{
					render.DisplayName="Sawsbuck";
					}
				render.Tile = "Creatures/AzPx_SawsbuckSpTile.bmp";
				render.ColorString = "w";
				render.DetailColor = "M";
				parent.GetStat("Strength").BaseValue += 8;
				parent.GetStat("Agility").BaseValue += 4;
				parent.GetStat("Toughness").BaseValue += 4;
				parent.GetStat("Intelligence").BaseValue += 2;
				parent.GetStat("Willpower").BaseValue += 4;
				parent.GetStat("Ego").BaseValue += 4;
				parent.GetStat("AV").BaseValue += 4;
				BodyPart head = parent.GetFirstBodyPart("Head");
					head.ForceUnequip(false);
					parent.GetPart<Mutations>()?.AddMutation(new AzPx_PkHornLeech(), 1);
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else
			{
				AddPlayerMessage("Evolution commencing.");
				evostage = 1;
				GameObject parent = ParentObject;
				Render render = ParentObject.pRender;
				render.DisplayName = "Sawsbuck";
				render.Tile = "Creatures/AzPx_SawsbuckSpTile.bmp";
				render.ColorString = "w";
				render.DetailColor = "M";
				parent.GetStat("Strength").BaseValue += 8;
				parent.GetStat("Agility").BaseValue += 4;
				parent.GetStat("Toughness").BaseValue += 4;
				parent.GetStat("Intelligence").BaseValue += 2;
				parent.GetStat("Willpower").BaseValue += 4;
				parent.GetStat("Ego").BaseValue += 4;
				parent.GetStat("AV").BaseValue += 4;
				BodyPart head = parent.GetFirstBodyPart("Head");
					head.ForceUnequip(false);
					parent.GetPart<Mutations>()?.AddMutation(new AzPx_PkHornLeech(), 1);
			}
			
		}
		return true;
	}

}
}