using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qud.API;
using XRL.Core;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Capabilities;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;
using XRL.World.Parts.Skill;

namespace XRL.World.Parts
{
[Serializable]
public class AzPx_EvolutionTepig : IPart
{
	
	public int evostage = 0;
	
	public int evocheck = 0;
	
	public int levelcheck = 0;
	
	public override bool WantEvent(int ID, int cascade)
	{
	if(ID == AwardXPEvent.ID)
		return true;

	return base.WantEvent(ID, cascade);
	}


	public bool HandleEvolution()
	{
		if (evostage == 1 && evocheck <= 0)
		{
			GameObject parent = ParentObject;
					Render render = ParentObject.pRender;
					if (parent.IsPlayer())
					{
						render.Tile="Player/AzPx_PigniteTile.bmp";
					}
					else
					{
					render.Tile="Creatures/AzPx_PigniteTile.bmp";
					}
					if (render.DisplayName == "Tepig")
					{
					render.DisplayName="Pignite";
					}
					render.ColorString="O";
					render.DetailColor="K";
					parent.GetStat("Strength").BaseValue += 7;
					parent.GetStat("Agility").BaseValue += 2;
					parent.GetStat("Toughness").BaseValue += 5;
					parent.GetStat("Intelligence").BaseValue += 2;
					parent.GetStat("Willpower").BaseValue += 2;
					parent.GetStat("Ego").BaseValue += 5;
					parent.GetStat("AV").BaseValue += 1;
					parent.GetStat("MoveSpeed").BaseValue += 50;
					foreach(GameObject item in parent.GetEquippedObjects())
					{
						item.ForceUnequip(true);
					}
					parent.Body.Anatomy = "AzPx_TailedBipedPk";
					evocheck = 1;
					
		}
		if (evostage == 2 && evocheck <= 1)
		{
					GameObject parent = ParentObject;
					Render render = ParentObject.pRender;
					if (parent.IsPlayer())
					{
						render.Tile="Player/AzPx_EmboarTile.bmp";
					}
					else
					{
					render.Tile="Creatures/AzPx_EmboarTile.bmp";
					}
					if (render.DisplayName == "Pignite")
					{
					render.DisplayName="Emboar";
					}
					render.ColorString="O";
					render.DetailColor="K";
					parent.GetStat("Strength").BaseValue += 6;
					parent.GetStat("Agility").BaseValue += 2;
					parent.GetStat("Toughness").BaseValue += 4;
					parent.GetStat("Intelligence").BaseValue += 2;
					parent.GetStat("Willpower").BaseValue += 2;
					parent.GetStat("Ego").BaseValue += 6;
					parent.GetStat("AV").BaseValue += 1;
					parent.GetPart<Mutations>()?.AddMutation(new AzPx_PkFlamethrower(), 1);
					evocheck = 2;
		}
		return true;
	}

	public override bool HandleEvent(AwardXPEvent E)
	{
		if (ParentObject.Stat("Level") >= 9 && ParentObject.GetPart<Mutations>().GetMutation("AzPx_PkTackle2") != null)
		{
			if (ParentObject.IsPlayer())
			{
			AddPlayerMessage("Your Tackle is replaced by Flame Charge!");
			}
			BaseMutation tackle = ParentObject.GetPart<Mutations>()?.GetMutation("AzPx_PkTackle2");
			ParentObject.GetPart<Mutations>()?.RemoveMutation(tackle);
			ParentObject.GetPart<Mutations>()?.AddMutation(new AzPx_PkFlameCharge(), 1);
		}
		if (ParentObject.Stat("Level") >= 12 && evostage == 0 && ParentObject.Stat("Level") > levelcheck)
		{
			if (ParentObject.IsPlayer())
			{
				if (Popup.ShowYesNo("You swell with energy. You are ready to evolve. Will you?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 1;		
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else if (ParentObject.IsPlayerLed())
			{
				if (Popup.ShowYesNo("Your " + ParentObject.DisplayName + " swells with energy. They are ready to evolve. Will you allow them?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 1;
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else
			{
				AddPlayerMessage("Evolution commencing.");
					evostage = 1;
			}
			
		}
		if ( evostage == 1 && evocheck == 0)
		{
			HandleEvolution();
		}
		
		if (ParentObject.Stat("Level") >= 24 && evostage == 1 && evocheck == 1 && ParentObject.Stat("Level") > levelcheck)
		{
			if (ParentObject.IsPlayer())
			{
				if (Popup.ShowYesNo("You swell with energy. You are ready to evolve. Will you?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 2;
				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}	
			}
			else if (ParentObject.IsPlayerLed())
			{
				if (Popup.ShowYesNo("Your " + ParentObject.DisplayName + " swells with energy. They are ready to evolve. Will you allow them?", AllowEscape: false) == DialogResult.Yes)
				{
					AddPlayerMessage("Evolution commencing.");
					evostage = 2;

				}
				else
				{
					levelcheck = ParentObject.GetStatValue("Level", 1);
				}
			}
			else
			{
				AddPlayerMessage("Evolution commencing.");
					evostage = 2;

			}
		}
		if ( evostage == 2 & evocheck <= 1)
		{
			HandleEvolution();
		}
		return true;
	}

}
}