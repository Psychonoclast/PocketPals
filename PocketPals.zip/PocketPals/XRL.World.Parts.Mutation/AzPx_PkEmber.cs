using System;
using System.Collections.Generic;
using System.Threading;
using ConsoleLib.Console;
using XRL;
using XRL.Core;
using XRL.Language;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_PkEmber : BaseMutation
{

	public bool CreateObject = true;

	public Guid EmberActivatedAbilityID = Guid.Empty;

			public override bool CanLevel()
	{
		return false;
	}

	public AzPx_PkEmber()
	{
		DisplayName = "Ember";
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "AttackerHit");
		Object.RegisterPartEvent(this, "CommandEmber");
		Object.RegisterPartEvent(this, "AIGetOffensiveMutationList");
		base.Register(Object);
	}

	public override string GetDescription()
	{
		return "You emit a burst of small embers to damage your target.";
	}

	public override string GetLevelText(int Level)
	{
		return "";
	}


	public string ComputeDamage(int UseLevel)
	{
		string text = "1d" + (4 + ParentObject.Statistics["Ego"].Modifier / 2);
		return text;
	}

	public string ComputeDamage()
	{
		string text = "1d" + (4 + ParentObject.Statistics["Ego"].Modifier / 2);
		return text;
	}

	public void Flame(Cell C, ScreenBuffer Buffer, bool doEffect = true)
	{
		string dice = ComputeDamage();
		if (C != null)
		{
			foreach (GameObject item in C.GetObjectsInCell())
			{
				if (!item.PhaseMatches(ParentObject))
				{
					continue;
				}
				item.TemperatureChange(125, ParentObject);
				if (doEffect)
				{
					for (int i = 0; i < 5; i++)
					{
						item.ParticleText("&r" + (char)(219 + Stat.Random(0, 4)), 2.9f, 1);
					}
					for (int j = 0; j < 5; j++)
					{
						item.ParticleText("&R" + (char)(219 + Stat.Random(0, 4)), 2.9f, 1);
					}
					for (int k = 0; k < 5; k++)
					{
						item.ParticleText("&W" + (char)(219 + Stat.Random(0, 4)), 2.9f, 1);
					}
				}
			}
			DieRoll cachedDieRoll = dice.GetCachedDieRoll();
			foreach (GameObject item2 in C.GetObjectsWithPartReadonly("Combat"))
			{
				if (item2.PhaseMatches(ParentObject))
				{
					Damage damage = new Damage(cachedDieRoll.Resolve());
					damage.AddAttribute("Fire");
					damage.AddAttribute("Heat");
					Event @event = Event.New("TakeDamage");
					@event.SetParameter("Damage", damage);
					@event.SetParameter("Owner", ParentObject);
					@event.SetParameter("Attacker", ParentObject);
					@event.SetParameter("Message", "from %o flames!");
					item2.FireEvent(@event);
				}
			}
		}
		if (doEffect)
		{
			Buffer.Goto(C.X, C.Y);
			string text = "&C";
			int num = Stat.Random(1, 3);
			if (num == 1)
			{
				text = "&R";
			}
			if (num == 2)
			{
				text = "&r";
			}
			if (num == 3)
			{
				text = "&W";
			}
			int num2 = Stat.Random(1, 3);
			if (num2 == 1)
			{
				text += "^R";
			}
			if (num2 == 2)
			{
				text += "^r";
			}
			if (num2 == 3)
			{
				text += "^W";
			}
			if (C.ParentZone == XRLCore.Core.Game.ZoneManager.ActiveZone)
			{
				Stat.Random(1, 3);
				Buffer.Write(text + (char)(219 + Stat.Random(0, 4)));
				Popup._TextConsole.DrawBuffer(Buffer);
				Thread.Sleep(10);
			}
		}
	}

	public static bool Cast(AzPx_PkEmber mutation = null, string level = "5-6")
	{
		if (mutation == null)
		{
			mutation = new AzPx_PkEmber();
			mutation.Level = Stat.Roll(level);
			mutation.ParentObject = XRLCore.Core.Game.Player.Body;
		}
		ScreenBuffer scrapBuffer = ScreenBuffer.GetScrapBuffer1(bLoadFromCurrent: true);
		XRLCore.Core.RenderMapToBuffer(scrapBuffer);
		List<Cell> list = mutation.PickLine(6, AllowVis.Any);
		if (list == null || list.Count <= 0)
		{
			return false;
		}
		if (list.Count == 1 && mutation.ParentObject.IsPlayer() && Popup.ShowYesNoCancel("Are you sure you want to target " + mutation.ParentObject.itself + "?") != 0)
		{
			return false;
		}
		mutation.UseEnergy(1000);
		mutation.CooldownMyActivatedAbility(mutation.EmberActivatedAbilityID, 2);
		mutation.PlayWorldSound("AzPx_SFXEmber", 0.5f, 0f, combat: true);
		int i = 0;
		for (int num = Math.Min(list.Count, 7); i < num; i++)
		{
			if (list.Count == 1 || list[i] != mutation.ParentObject.CurrentCell)
			{
				mutation.Flame(list[i], scrapBuffer);
			}
			if (i < num - 1 && list[i].IsSolidFor(null, mutation.ParentObject))
			{
				break;
			}
		}
		return true;
	}

	public override bool FireEvent(Event E)
	{
		if (E.ID == "AIGetOffensiveMutationList")
		{
			if (E.GetIntParameter("Distance") <= 6 && IsMyActivatedAbilityAIUsable(EmberActivatedAbilityID) && ParentObject.HasLOSTo(E.GetGameObjectParameter("Target"), bIncludeSolid: true, UseTargetability: true))
			{
				E.AddAICommand("CommandEmber");
			}
		}
		else if (E.ID == "CommandEmber")
		{
			return Cast(this);
		}
		return base.FireEvent(E);
	}

	public override bool ChangeLevel(int NewLevel)
	{
		return base.ChangeLevel(NewLevel);
	}

	private void AddAbility()
	{
		EmberActivatedAbilityID = AddMyActivatedAbility("Ember", "CommandEmber", "Physical Mutation");
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		Unmutate(GO);
		AddAbility();
		ChangeLevel(Level);
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		RemoveMyActivatedAbility(ref EmberActivatedAbilityID);
		return base.Unmutate(GO);
	}
}
}