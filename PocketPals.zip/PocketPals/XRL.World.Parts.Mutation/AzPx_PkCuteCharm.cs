using System;
using System.Collections.Generic;
using System.Threading;
using ConsoleLib.Console;
using XRL.Core;
using XRL.Language;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Effects;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_PkCuteCharm : BaseMutation
{

	public AzPx_PkCuteCharm()
	{
		DisplayName = "Cute Charm";
	}

	public override bool CanLevel()
	{
		return false;
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "DefendMeleeHit");
		base.Register(Object);
	}

	public override bool FireEvent(Event E)
	{

		 if (E.ID == "DefendMeleeHit")
		{
			if (10.in100())
			{
				GameObject weapon = E.GetParameter("Weapon") as GameObject;
				GameObject defender = E.GetParameter("Defender") as GameObject;
				GameObject attacker = E.GetParameter("Attacker") as GameObject;
				attacker.ApplyEffect(new Lovesick(50, defender), defender);
			}
		}
			
		return base.FireEvent(E);
	}

	public override string GetDescription()
	{
		return "Your jubilant countenance charms would be aggressors.";
	}

	public override string GetLevelText(int Level)
	{
		return "";
	}

	public override bool ChangeLevel(int NewLevel)
	{
		return base.ChangeLevel(NewLevel);
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		return base.Unmutate(GO);
	}
}
}