using System;
using System.Collections.Generic;
using System.Text;
using XRL.Messages;
using XRL.Rules;
using XRL.World;
using XRL.World.Parts;

namespace XRL.World.Parts.Mutation
{
    [Serializable]
    public class AzPx_PkLeafBlade : BaseDefaultEquipmentMutation
    {
		private List<GameObject> WeaponsUsed = new List<GameObject>(1);
		
		
		public override bool CanLevel()
		{
			return false;
		}
		
		
		public override void Register(GameObject Object)
		{
		Object.RegisterPartEvent(this, "AttackerAfterAttack");
		Object.RegisterPartEvent(this, "AttackerMeleeMiss");
		Object.RegisterPartEvent(this, "EndSegment");
		base.Register(Object);
		}
		
        public bool Mutating = false;

        public string BodyPartType = "Hand";
		
		public GameObject newAzPx_Jaws;

        public AzPx_PkLeafBlade()
        {
            this.DisplayName = "Leaf Blade";
        }

        public override bool GeneratesEquipment()
        {
            return true;
        }

		public int GetAttackChance(int Level)
	{
		return 10;
	}
		
	
	public override IPart DeepCopy(GameObject Parent)
	{
		newAzPx_Jaws = GameObjectFactory.Factory.CreateObject("AzPx_Jaws");
		return base.DeepCopy(Parent);
	}


        public override string GetDescription()
        {
			
                return "A large rigid and razor sharp leaf takes form in your hand. You occasionally slash your opponents.\n\n";
        
		}

        public override string GetLevelText(int Level)
        {
			return "";
		}

		public override bool FireEvent(Event E)
	{
		if (WeaponsUsed == null)
		{
			WeaponsUsed = new List<GameObject>(1);
		}
		else if (E.ID == "EndSegment")
		{
			WeaponsUsed.Clear();
			return true;
		}
		else if (E.ID == "AttackerAfterAttack" || E.ID == "AttackerMeleeMiss")
		{
			GameObject gameObject = E.GetParameter("Attacker") as GameObject;
			GameObject gameObject2 = E.GetParameter("Weapon") as GameObject;
			GameObject gameObject3 = E.GetParameter("Defender") as GameObject;
			foreach (BodyPart part in ParentObject.GetPart<Body>()?.GetPart("Hand"))
			{
				GameObject gameObject4 = part.DefaultBehavior;
			int num = 15;
			if (gameObject2 != null && gameObject3 != null && gameObject4 != null && gameObject3.IsValid() && gameObject3.IsAlive() && !WeaponsUsed.CleanContains(gameObject2) && gameObject2.IsEquippedOrDefaultOfPrimary(gameObject) && gameObject2 != gameObject4)
			{
				WeaponsUsed.Add(gameObject2);
				if (gameObject2.HasPart("MeleeWeapon") && Stat.Random(1, 100) <= num)
				{
					Event @event = Event.New("MeleeAttackWithWeapon");
					@event.AddParameter("Attacker", gameObject);
					@event.AddParameter("Defender", gameObject3);
					@event.AddParameter("Weapon", gameObject4);
					gameObject.FireEvent(@event);
					return false;
				}
			}
			}
			return true;
		}
		
		return base.FireEvent(E);
	}

		
			

        public override void OnRegenerateDefaultEquipment(Body body)
        {
            foreach (BodyPart Hand in ParentObject.GetPart<Body>().GetPart(this.BodyPartType))
            {
                if (Hand.VariantType == "Hand")
                {
                    if (!Mutating)
                    {
                        GameObject jawToDestroy = Hand.DefaultBehavior;
                        if (jawToDestroy != null)
                        {
                            jawToDestroy.Destroy();
                        }
                    }

                    GameObject newAzPx_Jaws = GameObjectFactory.Factory.CreateObject("AzPx_Jaws");
                    MeleeWeapon meleeWeapon = newAzPx_Jaws.GetPart<MeleeWeapon>();
                    Armor armor = newAzPx_Jaws.Armor;
                    Render render = newAzPx_Jaws.pRender;
                    render.DisplayName = "{{G|verdant blade}}";
                    meleeWeapon.Skill = "LongBlades";
                    meleeWeapon.BaseDamage = "2d8";
                    armor.WornOn = Hand.Type;
                    armor.AV = 0;


                    Hand.DefaultBehavior = newAzPx_Jaws;
                }
            }

            Mutating = false;
            base.OnRegenerateDefaultEquipment(body);
        }
		
			


        public override bool ChangeLevel(int NewLevel)
        {
            return base.ChangeLevel(NewLevel);
        }

		public override bool Mutate(GameObject GO, int Level)
        {
            this.ChangeLevel(Level);
			return base.Mutate(GO, Level);
		}

        public override bool Unmutate(GameObject GO)
        {
            foreach (BodyPart Hand in ParentObject.GetPart<Body>().GetPart("Hand"))
            {
                GameObject jawToDestroy = Hand.DefaultBehavior;
                base.CleanUpMutationEquipment(GO, ref jawToDestroy);
            }
            return base.Unmutate(GO);
        }
    }
}

