using System;
using XRL.Core;
using XRL.Language;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_PkSpinedCarapace : BaseDefaultEquipmentMutation
{
	public int ACModifier;

	public int DVModifier;

	public int ResistanceMod;

	public Guid ActivatedAbilityID = Guid.Empty;

	public bool Tight;

	public int TightFactor;

	public GameObject CarapaceObject;

	public int bodyID = int.MinValue;

	public override IPart DeepCopy(GameObject Parent)
	{
		Carapace obj = base.DeepCopy(Parent) as Carapace;
		obj.CarapaceObject = null;
		return obj;
	}

	public AzPx_PkSpinedCarapace()
	{
		DisplayName = "Spined Carapace";
	}

	public override bool GeneratesEquipment()
	{
		return true;
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "AIGetDefensiveMutationList");
		Object.RegisterPartEvent(this, "BeginMove");
		Object.RegisterPartEvent(this, "CommandTightenCarapace");
		Object.RegisterPartEvent(this, "IsMobile");
		Object.RegisterPartEvent(this, "UsingEnergy");
		Object.RegisterPartEvent(this, "DefendMeleeHit");
		base.Register(Object);
	}

	public override string GetDescription()
	{
		return "You are protected by a durable carapace.";
	}

	public override string GetLevelText(int Level)
	{
		string text = "+{{C|" + (2 + 2 * Level) + "}} AV\n";
		text += "-2 DV\n";
		text += "You may tighten your carapace to receive double the AV bonus at a -2 DV penalty as long as you remain still. While you are tightened, any melee attacker that hits you takes 1/2 their Strength in damage.\n";
		return text += "Cannot wear armor.\n";
	}

	public override bool FireEvent(Event E)
	{
		if (E.ID == "AIGetDefensiveMutationList")
		{
			int high = Math.Max(ParentObject.baseHitpoints - E.GetIntParameter("Distance"), 1);
			if (!Tight && ACModifier >= 1 && ParentObject.HasStat("Hitpoints") && IsMyActivatedAbilityAIUsable(ActivatedAbilityID) && Stat.Random(0, high) > ParentObject.hitpoints)
			{
				E.AddAICommand("CommandTightenCarapace");
			}
		}
		else if (E.ID == "DefendMeleeHit" && Tight == true)
			{
				GameObject attacker = E.GetParameter("Attacker") as GameObject;
				if (attacker != null && attacker != ParentObject)
				{
					{
						int reflectedamount = attacker.Stat("Strength") / 2;
						if (reflectedamount == 0)
						{
							reflectedamount = 1;
						}
						if (reflectedamount > 0)
						{
							if (ParentObject.IsPlayer())
							{
								IComponent<GameObject>.AddPlayerMessage("{{G|" + attacker.The + attacker.ShortDisplayName + attacker.GetVerb("impale") + " " + attacker.itself + " on your spines and takes " + reflectedamount + " damage!}}");
							}
							else if (attacker != null)
							{
								if (attacker.IsPlayer())
								{
									IComponent<GameObject>.AddPlayerMessage("You impale " + attacker.itself + " on " + Grammar.MakePossessive(ParentObject.the + ParentObject.ShortDisplayName) + " spines and take " + reflectedamount + " damage!", 'R');
								}
								else if (IComponent<GameObject>.Visible(attacker))
								{
									if (attacker.IsPlayerLed())
									{
										IComponent<GameObject>.AddPlayerMessage("{{r|" + attacker.The + attacker.ShortDisplayName + attacker.GetVerb("impale") + " " + attacker.itself + " on " + Grammar.MakePossessive(ParentObject.the + ParentObject.DisplayName) + " spines and takes " + reflectedamount + " damage!}}");
									}
									else
									{
										IComponent<GameObject>.AddPlayerMessage("{{g|" + attacker.The + attacker.ShortDisplayName + attacker.GetVerb("impale") + " " + attacker.itself + " on " + Grammar.MakePossessive(ParentObject.the + ParentObject.DisplayName) + " spines and takes " + reflectedamount + " damage!}}");
									}
								}
							}
							Event @event = new Event("TakeDamage");
							Damage hitfor = new Damage(reflectedamount);
							hitfor.Attributes.Add("reflected");
							@event.AddParameter("Damage", hitfor);
							@event.AddParameter("Owner", ParentObject);
							@event.AddParameter("Attacker", ParentObject);
							@event.AddParameter("Message", null);
							attacker.FireEvent(@event);
							ParentObject.FireEvent("ReflectedDamage");
						}
					}
				}
			}
		else if (E.ID == "CommandTightenCarapace")
		{
			Loosen();
			int aCModifier = ACModifier;
			if (aCModifier < 1)
			{
				if (ParentObject.IsPlayer())
				{
					Popup.Show("You fail to tighten your carapace.");
				}
			}
			else
			{
				UseEnergy(1000, "Mutation Tighten Carapace");
				Tighten();
				XRLCore.Core.RenderBase();
				if (ParentObject.IsPlayer())
				{
					Popup.Show("You tighten your carapace. You defend yourself with {{G|" + 2 * aCModifier + "}} increased AV and spines.");
				}
				else
				{
					DidX("tighten", ParentObject.its + " carapace", null, null, null, null, UseFullNames: false, IndefiniteSubject: false, null, null, AlwaysVisible: false, FromDialog: true);
				}
			}
		}
		else if (E.ID == "UsingEnergy")
		{
			if (Tight)
			{
				string stringParameter = E.GetStringParameter("Type", "");
				if (!stringParameter.Contains("Pass") && !stringParameter.Contains("Mental") && !stringParameter.Contains("Carapace"))
				{
					Loosen();
					if (ParentObject.IsPlayer())
					{
						Popup.Show("Your carapace loosens. Your AV decreases by {{R|" + 2 * ACModifier + "}}.");
					}
					else
					{
						IComponent<GameObject>.EmitMessage(ParentObject, Grammar.MakePossessive(ParentObject.The + ParentObject.ShortDisplayName) + " carapace loosens.");
					}
				}
			}
		}
		else if (E.ID == "BeginMove" && Tight && !E.HasFlag("Forced") && E.GetStringParameter("Type") != "Teleporting")
		{
			Loosen();
			if (ParentObject.IsPlayer())
			{
				Popup.Show("Your carapace loosens. Your AV decreases by {{R|" + 2 * ACModifier + "}}.");
			}
			else
			{
				IComponent<GameObject>.EmitMessage(ParentObject, Grammar.MakePossessive(ParentObject.The + ParentObject.ShortDisplayName) + " carapace loosens.");
			}
		}
		return base.FireEvent(E);
	}

	public void Tighten()
	{
		if (!Tight)
		{
			Tight = true;
			TightFactor = 2 * ACModifier;
			ParentObject.Statistics["AV"].Bonus += TightFactor;
			ParentObject.Statistics["DV"].Penalty += 2;
		}
	}

	public void Loosen()
	{
		if (Tight)
		{
			ParentObject.Statistics["AV"].Bonus -= TightFactor;
			ParentObject.Statistics["DV"].Penalty -= 2;
			Tight = false;
			TightFactor = 0;
		}
	}

	public override bool ChangeLevel(int NewLevel)
	{
		Loosen();
		ACModifier = 2 + 2 * Level;
		DVModifier = -2;
		if (CarapaceObject != null)
		{
			Armor part = CarapaceObject.GetPart<Armor>();
			part.AV = ACModifier;
			part.DV = DVModifier;
		}
		return base.ChangeLevel(NewLevel);
	}

	public override void OnRegenerateDefaultEquipment(Body body)
	{
		AddCarapaceTo(body.GetPartByID(bodyID));
	}

	public void AddCarapaceTo(BodyPart body)
	{
		if (body != null)
		{
			if (CarapaceObject == null)
			{
				CarapaceObject = GameObjectFactory.Factory.CreateObject("Carapace");
			}
			if (body.Equipped != CarapaceObject)
			{
				body.ParentBody.FireEvent(Event.New("CommandForceUnequipObject", "BodyPart", body));
				Event @event = new Event("CommandForceEquipObject");
				@event.AddParameter("Object", CarapaceObject);
				@event.AddParameter("BodyPart", body);
				@event.SetSilent(Silent: true);
				body.ParentBody.ParentObject.FireEvent(@event);
			}
		}
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		Body body = GO.Body;
		if (body != null)
		{
			BodyPart body2 = body.GetBody();
			bodyID = body2.ID;
			AddCarapaceTo(body2);
			ActivatedAbilityID = AddMyActivatedAbility("Tighten Carapace", "CommandTightenCarapace", "Physical Mutation");
		}
		ChangeLevel(Level);
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		Loosen();
		CleanUpMutationEquipment(GO, ref CarapaceObject);
		RemoveMyActivatedAbility(ref ActivatedAbilityID);
		return base.Unmutate(GO);
	}
}
}