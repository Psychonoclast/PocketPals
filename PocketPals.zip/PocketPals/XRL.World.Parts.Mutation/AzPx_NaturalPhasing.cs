using System;
using XRL.UI;
using XRL.World;
using XRL.World.Effects;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_NaturalPhasing : BaseMutation
{
	public Guid PhaseOutActivatedAbilityID = Guid.Empty;

	public AzPx_NaturalPhasing()
	{
		DisplayName = "Natural Phasing";
	}
	
	public override bool CanLevel()
	{
		return false;
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "BeginTakeAction");
		Object.RegisterPartEvent(this, "CommandTogglePhase");
		Object.RegisterPartEvent(this, "CommandPhaseOut");
		Object.RegisterPartEvent(this, "CommandPhaseIn");
		Object.RegisterPartEvent(this, "AIGetOffensiveMutationList");
		base.Register(Object);
	}

	public override string GetDescription()
	{
		return "You may phase through solid objects at will.";
	}

	public override string GetLevelText(int Level)
	{
		string text = "Duration: {{rules|indefinite}}\n";
		return text + "Cooldown: {{rules|none}}";
	}

	public void SyncAbilities()
	{
		ActivatedAbilityEntry activatedAbility = ParentObject.GetActivatedAbility(PhaseOutActivatedAbilityID);
		activatedAbility.ToggleState = ParentObject.HasEffect("Phased");
		activatedAbility.Visible = true;
	}

	public bool IsPhased()
	{
		return ParentObject?.HasEffect("Phased") ?? false;
	}

	public override bool FireEvent(Event E)
	{
		if (E.ID == "BeginTakeAction")
		{
			SyncAbilities();
		}
		else
		{
			if (E.ID == "CommandTogglePhase")
			{
				return ParentObject.FireEvent(Event.New(IsPhased() ? "CommandPhaseIn" : "CommandPhaseOut"));
			}
			if (E.ID == "CommandPhaseOut")
			{
				if (ParentObject.OnWorldMap())
				{
					if (ParentObject.IsPlayer())
					{
						Popup.ShowFail("You cannot do that on the world map.");
					}
					return true;
				}
				Event e = Event.New("InitiateRealityDistortionLocal", "Object", ParentObject, "Mutation", this);
				if (!ParentObject.FireEvent(e, E))
				{
					return true;
				}
				ParentObject.ApplyEffect(new Phased(9999));
				SyncAbilities();
			}
			else if (E.ID == "CommandPhaseIn")
			{
				ParentObject.RemoveEffect("Phased");
				SyncAbilities();
			}
			else if (E.ID == "AIGetOffensiveMutationList")
			{
				int intParameter = E.GetIntParameter("Distance");
				if (intParameter > 1 && intParameter < 5 + base.Level && IsMyActivatedAbilityAIUsable(PhaseOutActivatedAbilityID) && ParentObject.FireEvent(Event.New("CheckRealityDistortionAdvisability", "Mutation", this)))
				{
					E.AddAICommand("CommandPhaseOut");
				}
			}
		}
		return base.FireEvent(E);
	}

	public override bool ChangeLevel(int NewLevel)
	{
		return base.ChangeLevel(NewLevel);
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		PhaseOutActivatedAbilityID = AddMyActivatedAbility("Phase", "CommandTogglePhase", "Physical Mutation", null, "\a", null, Toggleable: true, DefaultToggleState: false, ActiveToggle: false, IsAttack: false, IsRealityDistortionBased: true);
		ChangeLevel(Level);
		SyncAbilities();
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		RemoveMyActivatedAbility(ref PhaseOutActivatedAbilityID);
		return base.Unmutate(GO);
	}
}
}
