
using System;
using System.Collections.Generic;
using System.Text;
using XRL.Core;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Capabilities;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_PkSwiftSwim : BaseMutation
{
		
		public int MS = 100;

	public int MinVolume = 200;

	public int CurrentBonus = 0;

	public string Liquid;

	public AzPx_PkSwiftSwim()
	{
		DisplayName = "Swift Swim";
	}

	public override bool CanLevel()
	{
		return false;
	}

	public override string GetDescription()
	{
		return "Your physiology gives you a natural predisposition towards swimming./nYou move twice as fast in deep liquids.";
	}

	public override string GetLevelText(int Level)
	{
		return "";
	}

	public override bool WantEvent(int ID, int cascade)
	{
		if (ID == EnteredCellEvent.ID || ID == EndTurnEvent.ID)
		{
			CheckLiquid();
			return true;
		}
		return base.WantEvent(ID, cascade);
	}
		
	private void CheckLiquid()
	{
		GameObject parent = ParentObject;
		Cell currentCell = parent.CurrentCell;
		if (currentCell == null)
		{
			return;
		}
		bool flag = false;
		int i = 0;
		for (int count = currentCell.Objects.Count; i < count; i++)
		{
			LiquidVolume liquidVolume = currentCell.Objects[i].LiquidVolume;
			if (liquidVolume != null && liquidVolume.IsOpenVolume() && liquidVolume.Volume >= MinVolume && (string.IsNullOrEmpty(Liquid) || liquidVolume.Amount(Liquid) >= MinVolume))
			{
				flag = true;
				break;
			}
		}
		if (flag)
		{
			if (CurrentBonus == 0)
			{
				CurrentBonus = MS;
				base.StatShifter.SetStatShift(parent, "MoveSpeed", -MS);
			}
		}
		else if (CurrentBonus > 0)
		{
			base.StatShifter.RemoveStatShift(parent, "MoveSpeed");
			CurrentBonus = 0;
		}
	}

	public override bool ChangeLevel(int NewLevel)
	{
		return base.ChangeLevel(NewLevel);
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		return base.Unmutate(GO);
	}
	
}
}
