using System;
using System.Collections.Generic;
using System.Threading;
using ConsoleLib.Console;
using XRL;
using XRL.Core;
using XRL.Language;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_PkThunderShock : BaseMutation
{
	public Guid ThunderShockActivatedAbilityID = Guid.Empty;

	public int ChargeCount = 15;

	public int AmmoRegrowthTimer;

	public AzPx_PkThunderShock()
	{
		DisplayName = "Thunder Shock";
	}
	
			public override bool CanLevel()
	{
		return false;
	}

	public override bool HandleEvent(GetItemElementsEvent E)
	{
		E.Add("stars", 1);
		return true;
	}

	public override bool AllowStaticRegistration()
	{
		return true;
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "AIGetOffensiveMutationList");
		Object.RegisterPartEvent(this, "CommandThunderShock");
		Object.RegisterPartEvent(this, "EndTurn");
		base.Register(Object);
	}

	public override string GetDescription()
	{
		return "You launch a long arc of electricity at your target.";
	}

	public override string GetLevelText(int Level)
	{
		return "";
	}

	public string GetDamage(int Level)
	{
		return "1d2+" + ParentObject.Statistics["Ego"].Modifier / 2;
	}

	public int GetThunderShockPenetrationBonus()
	{
		return 4 + ParentObject.Statistics["Ego"].Modifier / 2;
	}

	public bool FireAttack(Cell C, int PathLength = 0)
	{
		_ = Look._TextConsole;
		ScreenBuffer screenBuffer = TextConsole.ScrapBuffer.WithMap();
		bool flag = false;
		bool flag2 = false;
		if (C != null)
		{
			GameObject combatTarget = C.GetCombatTarget(ParentObject, IgnoreFlight: true, IgnorePhase: false, IgnoreAttackable: false, null, AllowInanimate: true, InanimateSolidOnly: true);
			if (combatTarget != null)
			{
				int psyPenetrationBonus = GetThunderShockPenetrationBonus();
				int num = Stat.RollDamagePenetrations(combatTarget.Stat("AV"), psyPenetrationBonus, psyPenetrationBonus);
				if (num > 0)
				{
					string resultColor = Stat.GetResultColor(num);
					int num2 = 0;
					string damage = GetDamage(base.Level);
					for (int i = 0; i < num; i++)
					{
						num2 += damage.RollCached();
					}
					combatTarget.TakeDamage(num2, "Electric", null, null, ParentObject, null, "from %o Thunder Shock attack! {{" + resultColor + "|(x" + num + ")}}", Accidental: false, ShowUninvolved: false, ShowForInanimate: true);
					flag = true;
				}
				else if (ParentObject.IsPlayer())
				{
					IComponent<GameObject>.AddPlayerMessage("{{r|Your Thunder Shock attack doesn't penetrate " + Grammar.MakePossessive(combatTarget.the + combatTarget.ShortDisplayName) + " mental defense.}}");
				}
				else if (combatTarget.IsPlayer())
				{
					IComponent<GameObject>.AddPlayerMessage("{{g|" + ColorUtility.CapitalizeExceptFormatting(Grammar.MakePossessive(ParentObject.the + ParentObject.ShortDisplayName)) + " ThunderShock attack doesn't penetrate your mental defense.}}");
				}
			}
		}
		if (C.IsVisible() || ParentObject.IsPlayer())
		{
			switch (Stat.Random(1, 3))
			{
			case 1:
				screenBuffer.WriteAt(C, "&C\u000F");
				break;
			case 2:
				screenBuffer.WriteAt(C, "&W\u00F9");
				break;
			default:
				screenBuffer.WriteAt(C, "&W\u000F");
				break;
			}
			screenBuffer.Draw();
			int num3 = 10 - PathLength / 5;
			if (num3 > 0)
			{
				Thread.Sleep(num3);
			}
		}
		return flag || flag2;
	}

	public override bool FireEvent(Event E)
	{
		if (E.ID == "EndTurn")
		{
			AmmoRegrowthTimer++;
			if (AmmoRegrowthTimer >= 30)
			{
				AmmoRegrowthTimer = 0;
				if (ChargeCount < 8)
				{
				ChargeCount++;
				}
			}
		}
		else if (E.ID == "AIGetOffensiveMutationList")
		{
			if (E.GetIntParameter("Distance") <= 10 && ParentObject.HasLOSTo(E.GetGameObjectParameter("Target"), bIncludeSolid: true, UseTargetability: true))
			{
				E.AddAICommand("CommandThunderShock", 2);
			}
		}
		else if (E.ID == "CommandThunderShock")
		{
			if (IsMyActivatedAbilityUsable(ThunderShockActivatedAbilityID))
			{
				if (ChargeCount <= 0)
				{
					if (ParentObject.IsPlayer())
					{
						Popup.Show("Your move capacity is too exhausted.");
					}
					return true;
				}
				
				List<Cell> list = PickLine(22, AllowVis.Any, (GameObject o) => o.HasPart("Combat") && o.PhaseMatches(ParentObject));
				if (list == null)
				{
					return true;
				}
				if (list.Count <= 0)
				{
					return true;
				}
				if (list != null)
				{
					UseEnergy(1000);
					PlayWorldSound("AzPx_SFXThunderShock", 0.5f, 0f, combat: true);
					CooldownMyActivatedAbility(ThunderShockActivatedAbilityID, 2);
					Cell cell = list[0];
					Cell cell2 = list[list.Count - 1];
					float num = (float)Math.Atan2(cell2.X - cell.X, cell2.Y - cell.Y).toDegrees();
					list.RemoveAt(0);
					for (int i = 0; i < list.Count; i++)
					{
						Cell cell3 = list[i];
						bool flag = true;
						GameObject obj = null;
						string clip = null;
						string verb = "reflect";
						int num2 = -1;
						if (flag || !GameObject.validate(ref obj))
						{
							continue;
						}
						PlayWorldSound(clip, 0.5f, 0f, combat: true);
						IComponent<GameObject>.XDidY(obj, verb, "the ThunderShock attack", "!", null, obj);
						float num3 = cell3.X;
						float num4 = cell3.Y;
						float num5 = (float)Math.Sin((float)num2 * ((float)Math.PI / 180f));
						float num6 = (float)Math.Cos((float)num2 * ((float)Math.PI / 180f));
						list.RemoveRange(i, list.Count - i);
						Cell cell4 = cell3;
						do
						{
							num3 += num5;
							num4 += num6;
							Cell cell5 = cell3.ParentZone.GetCell((int)num3, (int)num4);
							if (cell5 == null)
							{
								break;
							}
							if (cell5 != cell4)
							{
								list.Add(cell5);
								cell4 = cell5;
								if (cell5.HasSolidObjectForMissile(ParentObject) || cell5.GetCombatTarget(ParentObject, IgnoreFlight: true, IgnorePhase: false, IgnoreAttackable: false, null, AllowInanimate: true, InanimateSolidOnly: true) != null)
								{
									break;
								}
							}
						}
						while (num3 > 0f && num3 < 79f && num4 > 0f && num4 < 24f && list.Count < 400);
					}
					int j = 0;
					for (int count = list.Count; j < count && !FireAttack(list[j], count); j++)
					{
					}
					ChargeCount--;
				}
			}
		}
		return base.FireEvent(E);
	}
	
	public override bool ChangeLevel(int NewLevel)
	{
		return base.ChangeLevel(NewLevel);
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		Unmutate(GO);
		ThunderShockActivatedAbilityID = AddMyActivatedAbility("Thunder Shock", "CommandThunderShock", "Physical Mutation", null, "*");
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		RemoveMyActivatedAbility(ref ThunderShockActivatedAbilityID);
		return base.Unmutate(GO);
	}
}
}