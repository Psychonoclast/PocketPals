using System;
using System.Collections.Generic;
using XRL.UI;
using XRL.World;
using XRL.World.Effects;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_PkChlorophyll : BaseMutation
{
	public Guid BaskActivatedAbilityID = Guid.Empty;

	public int SoakCounter;

	public override bool CanLevel()
	{
		return false;
	}

	public AzPx_PkChlorophyll()
	{
		DisplayName = "Chlorophyll";
	}

	public override bool AllowStaticRegistration()
	{
		return true;
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "BeginTakeAction");
		Object.RegisterPartEvent(this, "CommandBask");
		base.Register(Object);
	}

	public override string GetDescription()
	{
		return "You naturally generate energy through photosynthesis. After basking in sunlight, you gain a +25 bonus to Quickness and +50% regeneration rate.";
	}

	public override string GetLevelText(int Level)
	{
		return "";
	}

	public static int GetBonusRegeneration(int Level)
	{
		return 10 + 10 * Level;
	}

	public static int GetBonusQuickness(int Level)
	{
		return 10 + Level;
	}

	public static string GetStarchServings(int Level)
	{
		int num = (Level - 1) / 4 + 1;
		if (num != 1)
		{
			return num + " servings";
		}
		return num + " serving";
	}

	public static int GetBonusDuration(int Level)
	{
		return 3 + Level / 2;
	}

	public override bool FireEvent(Event E)
	{
		if (E.ID == "BeginTakeAction")
		{
			if (ParentObject.IsUnderSky() && IsDay() && !ParentObject.HasPart("Temporary"))
			{
				SoakCounter++;
				if (SoakCounter > Calendar.turnsPerHour * 6)
				{
					SoakCounter = 0;
					int num = (base.Level - 1) / 4 + 1;
					Inventory inventory = ParentObject.Inventory;
					if (inventory.Count("Starch") < num)
					{
						inventory.AddObject("Starch", bSilent: true);
					}
					if (inventory.Count("Lignin") < num)
					{
						inventory.AddObject("Lignin", bSilent: true);
					}
				}
			}
		}
		else if (E.ID == "CommandBask")
		{
			if (IsDay())
			{
				if (ParentObject.CurrentCell.ParentZone.IsWorldMap() || ParentObject.CurrentCell.ParentZone.GetZoneZ() <= 10)
				{
					ProceduralCookingEffect proceduralCookingEffect = ProceduralCookingEffect.CreateSpecific(new List<string>
					{
						"CookingDomainPhotosyntheticSkin_RegenerationUnit",
						"CookingDomainPhotosyntheticSkin_UnitQuickness",
						"CookingDomainPhotosyntheticSkin_SatedUnit"
					});
					ParentObject.FireEvent("ClearFoodEffects");
					ParentObject.CleanEffects();
					proceduralCookingEffect.Init(ParentObject);
					proceduralCookingEffect.Duration = Calendar.turnsPerDay * GetBonusDuration(base.Level);
					ParentObject.ApplyEffect(proceduralCookingEffect);
					ParentObject.GetPart<Stomach>().HungerLevel = 0;
					ParentObject.GetPart<Stomach>().CookingCounter = 0;
					ParentObject.RemoveEffect("Famished");
					Popup.Show("You bask in the sunlight and absorb the nourishing rays.");
					Popup.Show("You start to metabolize the meal, gaining the following effect for the rest of the day:\n\n&W" + proceduralCookingEffect.GetDetails());
				}
				else
				{
					Popup.Show("You need sunlight to bask in.");
				}
			}
			else
			{
				Popup.Show("You need sunlight to bask in.");
			}
		}
		return base.FireEvent(E);
	}

	public override bool ChangeLevel(int NewLevel)
	{
		return base.ChangeLevel(NewLevel);
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		BaskActivatedAbilityID = AddMyActivatedAbility("Bask", "CommandBask", "Physical Mutation", "Bask in the sunlight and absorb the sun's nourishing rays.\n\n+20% + (Photosynthetic Skin level * 10)% to natural healing rate\n\n+13 + (Photosynthetic Skin level * 2) Quickness", "\u001a");
		ChangeLevel(Level);
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		RemoveMyActivatedAbility(ref BaskActivatedAbilityID);
		return base.Unmutate(GO);
	}
}
}
