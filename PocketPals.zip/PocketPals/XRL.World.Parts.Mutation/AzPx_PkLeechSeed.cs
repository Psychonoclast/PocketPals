// Warning: Some assembly references could not be resolved automatically. This might lead to incorrect decompilation of some parts,
// for ex. property getter/setter access. To get optimal decompilation results, please manually add the missing references to the list of loaded assemblies.
// XRL.World.Parts.Mutation.LightManipulation
using System;
using System.Collections.Generic;
using System.Threading;
using ConsoleLib.Console;
using XRL;
using XRL.Language;
using XRL.Rules;
using XRL.UI;
using XRL.World;
using XRL.World.Parts;
using XRL.World.Parts.Mutation;

namespace XRL.World.Parts.Mutation
{
[Serializable]
public class AzPx_PkLeechSeed : BaseMutation
{
	public Guid SeedsActivatedAbilityID = Guid.Empty;

	public Guid LightActivatedAbilityID = Guid.Empty;

	public int SeedCount = 3;

	public int SeedRechargeTimer;
	
			public override bool CanLevel()
	{
		return false;
	}

	public AzPx_PkLeechSeed()
	{
		DisplayName = "Leech Seed";
	}

	public override bool AllowStaticRegistration()
	{
		return true;
	}

	public override void Register(GameObject Object)
	{
		Object.RegisterPartEvent(this, "AIGetOffensiveMutationList");
		Object.RegisterPartEvent(this, "CommandSeeds");
		Object.RegisterPartEvent(this, "EndTurn");
		base.Register(Object);
	}

	public override string GetDescription()
	{
		return "You flick a handful of potent parasitic seeds at a target. They steal 1/6 your targets toughness per turn.";
	}

	public override string GetLevelText(int Level)
	{
		return "";
	}

	
	public bool FireAttack(Cell C, int PathLength = 0)
	{
		_ = Look._TextConsole;
		ScreenBuffer screenBuffer = TextConsole.ScrapBuffer.WithMap();
		bool flag = false;
		bool flag2 = false;
		if (C != null)
		{
			GameObject combatTarget = C.GetCombatTarget(ParentObject, IgnoreFlight: true, IgnorePhase: false, IgnoreAttackable: false, null, AllowInanimate: true, InanimateSolidOnly: true);
			if (combatTarget != null && ParentObject.DistanceTo(combatTarget) <= 8)
			{
				string seedhealth = (combatTarget.Stat("Toughness") / 6).ToString();
				int savelevel = 20 + ParentObject.Stat("Level");
				combatTarget.ApplyEffect(new XRL.World.Effects.LifeDrain(50, savelevel, seedhealth, ParentObject, false));
			}
		}
		if (C.IsVisible() || ParentObject.IsPlayer())
		{
			switch (Stat.Random(1, 3))
			{
			case 1:
				screenBuffer.WriteAt(C, "&G\u000f");
				break;
			case 2:
				screenBuffer.WriteAt(C, "&y\u000f");
				break;
			default:
				screenBuffer.WriteAt(C, "&g\u000f");
				break;
			}
			screenBuffer.Draw();
			int num3 = 10 - PathLength / 5;
			if (num3 > 0)
			{
				Thread.Sleep(num3);
			}
		}
		return flag || flag2;
	}


	public override bool FireEvent(Event E)
	{
		if (E.ID == "EndTurn")
		{
			SeedRechargeTimer++;
			if (SeedRechargeTimer >= 20)
			{
				SeedRechargeTimer = 0;
				if (SeedCount < 3)
				{
				SeedCount++;
				}
			}
		}
		else if (E.ID == "AIGetOffensiveMutationList")
		{
			if (E.GetIntParameter("Distance") <= 8 && ParentObject.HasLOSTo(E.GetGameObjectParameter("Target"), bIncludeSolid: true, UseTargetability: true))
			{
				E.AddAICommand("CommandSeeds", 2);
			}
		}
		else if (E.ID == "CommandSeeds")
		{
			if (IsMyActivatedAbilityUsable(SeedsActivatedAbilityID))
			{
				if (SeedCount <= 0)
				{
					if (ParentObject.IsPlayer())
					{
						Popup.Show("Your leech seed capacity is too exhausted.");
					}
					return true;
				}
				List<Cell> list = PickLine(8, AllowVis.Any, (GameObject o) => o.HasPart("Combat") && o.PhaseMatches(ParentObject));
				if (list == null)
				{
					return true;
				}
				if (list.Count <= 0)
				{
					return true;
				}
				if (list != null)
				{
					PlayWorldSound("AzPx_SFXLeechSeed", 0.5f, 0f, combat: true);
					UseEnergy(1000);
					CooldownMyActivatedAbility(SeedsActivatedAbilityID, 15);
					Cell cell = list[0];
					Cell cell2 = list[list.Count - 1];
					float num = (float)Math.Atan2(cell2.X - cell.X, cell2.Y - cell.Y).toDegrees();
					list.RemoveAt(0);
					for (int i = 0; i < list.Count; i++)
					{
						Cell cell3 = list[i];
						bool flag = true;
						GameObject obj = null;
						string clip = null;
						string verb = "reflect";
						int num2 = -1;
						if (flag || !GameObject.validate(ref obj))
						{
							continue;
						}
						PlayWorldSound(clip, 0.5f, 0f, combat: true);
						IComponent<GameObject>.XDidY(obj, verb, "the Psychic attack", "!", null, obj);
						float num3 = cell3.X;
						float num4 = cell3.Y;
						float num5 = (float)Math.Sin((float)num2 * ((float)Math.PI / 180f));
						float num6 = (float)Math.Cos((float)num2 * ((float)Math.PI / 180f));
						list.RemoveRange(i, list.Count - i);
						Cell cell4 = cell3;
						do
						{
							num3 += num5;
							num4 += num6;
							Cell cell5 = cell3.ParentZone.GetCell((int)num3, (int)num4);
							if (cell5 == null)
							{
								break;
							}
							if (cell5 != cell4)
							{
								list.Add(cell5);
								cell4 = cell5;
								if (cell5.HasSolidObjectForMissile(ParentObject) || cell5.GetCombatTarget(ParentObject, IgnoreFlight: true, IgnorePhase: false, IgnoreAttackable: false, null, AllowInanimate: true, InanimateSolidOnly: true) != null)
								{
									break;
								}
							}
						}
						while (num3 > 0f && num3 < 79f && num4 > 0f && num4 < 24f && list.Count < 400);
					}
					int j = 0;
					for (int count = list.Count; j < count && !FireAttack(list[j], count); j++)
					{
					}
					SeedCount--;
				}
			}
		}
		return base.FireEvent(E);
	}

	public override bool ChangeLevel(int NewLevel)
	{
		return base.ChangeLevel(NewLevel);
	}

	public override bool Mutate(GameObject GO, int Level)
	{
		Unmutate(GO);
		SeedsActivatedAbilityID = AddMyActivatedAbility("Leech Seed", "CommandSeeds", "Physical Mutation", null, "*");
		return base.Mutate(GO, Level);
	}

	public override bool Unmutate(GameObject GO)
	{
		RemoveMyActivatedAbility(ref SeedsActivatedAbilityID);
		return base.Unmutate(GO);
	}
}
}